import React from "react";
// import "./page_not_found.css";
import "./Sign_in.css";
import { useNavigate } from "react-router-dom";

function Page_not_found() {
  let navigate = useNavigate();
  return (
    <div className="sign_in_bg_image">
      <div class="main">
        <h1 className="h1">404</h1>
        <p className="p">Oops. Looks like you took a wrong turn.</p>
        <button type="button" className="back_btn" onClick={() => navigate(-1)}>
          Go back
        </button>
      </div>
    </div>
    // <div>
    //   <div class="container1 container-star min-vw-100">
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-1"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //     <div class="star-2"></div>
    //   </div>
    //   <div class="container1 container-bird">
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="bird bird-anim">
    //       <div class="bird-container">
    //         <div class="wing wing-left">
    //           <div class="wing-left-top"></div>
    //         </div>
    //         <div class="wing wing-right">
    //           <div class="wing-right-top"></div>
    //         </div>
    //       </div>
    //     </div>
    //     <div class="container-title">
    //       <div class="title1">
    //         <div class="number">4</div>
    //         <div class="moon">
    //           <div class="face">
    //             <div class="mouth"></div>
    //             <div class="eyes">
    //               <div class="eye-left"></div>
    //               <div class="eye-right"></div>
    //             </div>
    //           </div>
    //         </div>
    //         <div class="number">4</div>
    //       </div>
    //       <div class="subtitle">Oops. Looks like you took a wrong turn.</div>
    //       <button onClick={() => navigate(-1)}>Go back</button>
    //     </div>
    //   </div>
    // </div>
  );
}

export default Page_not_found;
